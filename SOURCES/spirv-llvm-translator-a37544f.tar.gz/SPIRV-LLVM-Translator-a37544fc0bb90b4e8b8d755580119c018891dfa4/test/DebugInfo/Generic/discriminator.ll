; REQUIRES: object-emission

; RUN: llvm-as < %s -o %t.bc
; RUN: llvm-spirv %t.bc -o %t.spv
; RUN: llvm-spirv -r %t.spv -o - | llvm-dis -o %t.ll

; RUN: llc -mtriple=%triple < %t.ll -filetype=obj | llvm-dwarfdump -debug-info - | FileCheck %s

target datalayout = "e-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-n8:16:32:64"
target triple = "spir64-unknown-unknown"

; Given the following source, ensure that the discriminator is emitted for
; the inlined callsite.

;void xyz();
;static void __attribute__((always_inline)) bar() { xyz(); }
;void foo() {
;  bar(); bar();
;}

;CHECK: DW_TAG_inlined_subroutine
;CHECK-NOT: DW_AT_GNU_discriminator
;CHECK: DW_TAG_inlined_subroutine
;CHECK-NOT: {{DW_TAG|NULL}}
;CHECK: DW_AT_GNU_discriminator{{.*}}0x01

; Function Attrs: uwtable
define void @_Z3foov() #0 !dbg !4 {
  tail call void @_Z3xyzv(), !dbg !11
  tail call void @_Z3xyzv(), !dbg !13
  ret void, !dbg !16
}

declare void @_Z3xyzv() #1

attributes #0 = { uwtable "disable-tail-calls"="false" "less-precise-fpmad"="false" "no-frame-pointer-elim"="false" "no-infs-fp-math"="false" "no-nans-fp-math"="false" "stack-protector-buffer-size"="8" "unsafe-fp-math"="false" "use-soft-float"="false" }
attributes #1 = { "disable-tail-calls"="false" "less-precise-fpmad"="false" "no-frame-pointer-elim"="false" "no-infs-fp-math"="false" "no-nans-fp-math"="false" "stack-protector-buffer-size"="8" "unsafe-fp-math"="false" "use-soft-float"="false" }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!8, !9}
!llvm.ident = !{!10}

!0 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus, file: !1, producer: "clang version 3.8.0 (trunk 252497)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !2)
!1 = !DIFile(filename: "a.cc", directory: "/tmp")
!2 = !{}
!4 = distinct !DISubprogram(name: "foo", linkageName: "_Z3foov", scope: !1, file: !1, line: 3, type: !5, isLocal: false, isDefinition: true, scopeLine: 3, flags: DIFlagPrototyped, isOptimized: true, unit: !0, retainedNodes: !2)
!5 = !DISubroutineType(types: !6)
!6 = !{null}
!7 = distinct !DISubprogram(name: "bar", linkageName: "_ZL3barv", scope: !1, file: !1, line: 2, type: !5, isLocal: true, isDefinition: true, scopeLine: 2, flags: DIFlagPrototyped, isOptimized: true, unit: !0, retainedNodes: !2)
!8 = !{i32 2, !"Dwarf Version", i32 4}
!9 = !{i32 2, !"Debug Info Version", i32 3}
!10 = !{!"clang version 3.8.0 (trunk 252497)"}
!11 = !DILocation(line: 2, column: 52, scope: !7, inlinedAt: !12)
!12 = distinct !DILocation(line: 4, column: 3, scope: !4)
!13 = !DILocation(line: 2, column: 52, scope: !7, inlinedAt: !14)
!14 = distinct !DILocation(line: 4, column: 10, scope: !15)
!15 = !DILexicalBlockFile(scope: !4, file: !1, discriminator: 1)
!16 = !DILocation(line: 5, column: 1, scope: !4)
