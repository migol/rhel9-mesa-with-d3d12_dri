//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef __CLC_SHARED_CLC_VLOAD_H__
#define __CLC_SHARED_CLC_VLOAD_H__

#include <clc/shared/clc_less_aligned_types.h>

#define __CLC_BODY <clc/shared/clc_vload.inc>
#include <clc/integer/gentype.inc>

#define __CLC_BODY <clc/shared/clc_vload.inc>
#include <clc/math/gentype.inc>

#endif // __CLC_SHARED_CLC_VLOAD_H__
