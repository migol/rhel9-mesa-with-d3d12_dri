//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef __CLC_MATH_CLC_FMA_H__
#define __CLC_MATH_CLC_FMA_H__

#define FUNCTION __clc_fma
#define __CLC_BODY <clc/shared/ternary_decl.inc>

#include <clc/math/gentype.inc>

#undef FUNCTION

#endif // __CLC_MATH_CLC_FMA_H__
