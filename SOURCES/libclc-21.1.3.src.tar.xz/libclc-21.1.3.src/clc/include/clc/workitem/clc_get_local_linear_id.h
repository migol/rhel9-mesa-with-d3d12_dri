//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef __CLC_WORKITEM_CLC_GET_LOCAL_LINEAR_ID_H__
#define __CLC_WORKITEM_CLC_GET_LOCAL_LINEAR_ID_H__

#include <clc/internal/clc.h>

_CLC_OVERLOAD _CLC_DECL size_t __clc_get_local_linear_id();

#endif // __CLC_WORKITEM_CLC_GET_LOCAL_LINEAR_ID_H__
