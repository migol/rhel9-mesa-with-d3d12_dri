//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef __CLC_OPENCL_MATH_COPYSIGN_H__
#define __CLC_OPENCL_MATH_COPYSIGN_H__

#define FUNCTION copysign
#define __CLC_BODY <clc/shared/binary_decl.inc>

#include <clc/math/gentype.inc>

#undef FUNCTION

#endif // __CLC_OPENCL_MATH_COPYSIGN_H__
